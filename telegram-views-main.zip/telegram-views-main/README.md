# Telegram Views V3
https://streamable.com/xyw76h 

## Features
- Auto Proxy scraping ( You don't have to get proxies )
- Auto Proxy rescraping ( Let it run for ever )


Install requirements
```
pip install -r requirements.txt
```
